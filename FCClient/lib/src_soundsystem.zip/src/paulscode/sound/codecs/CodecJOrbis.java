package paulscode.sound.codecs;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownServiceException;
import javax.sound.sampled.AudioFormat;

// From the JOrbis library, http://www.jcraft.com/jorbis/
import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;
import com.jcraft.jorbis.DspState;
import com.jcraft.jorbis.Block;
import com.jcraft.jorbis.Comment;
import com.jcraft.jorbis.Info;

import paulscode.sound.ICodec;
import paulscode.sound.SoundBuffer;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemLogger;

/**
 * The CodecJOrbis class provides an ICodec interface to the external JOrbis
 * library.
 *<b>
 *    This software is based on or using the JOrbis library available from
 *    http://www.jcraft.com/jorbis/
 *</b><br><br>
 *<br><b>
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * <br><br><br></b>
 *
 * <br><br>
 *    Author: Paul Lamb
 * <br>
 *    http://www.paulscode.com
 * </b><br><br>
 */
public class CodecJOrbis implements ICodec
{
/**
 * Used to return a current value from one of the synchronized
 * boolean-interface methods.
 */
    private static final boolean GET = false;

/**
 * Used to set the value in one of the synchronized boolean-interface methods.
 */
    private static final boolean SET = true;

/**
 * Used when a parameter for one of the synchronized boolean-interface methods
 * is not aplicable.
 */
    private static final boolean XXX = false;

/**
 * URL to the audio file to stream from.
 */
    private URL url;

/**
 * Used for connecting to the URL.
 */
	private URLConnection urlConnection = null;

/**
 * InputStream context for reading data from the file.
 */
    private InputStream inputStream;

/**
 * Format in which the converted audio data is stored.
 */
    private AudioFormat audioFormat;

/**
 * True if there is no more data to read in.
 */
    private boolean endOfStream = false;

/**
 * True if the stream has finished initializing.
 */
    private boolean initialized = false;

/**
 * Used to hold the data as it is read in.
 */
	private byte[] buffer = null;

/**
 * Amount of data to read in at one time.
 */
	private int bufferSize;

/**
 * Number of bytes read.
 */
	private int count = 0;

/**
 * Location within the data.
 */
	private int index = 0;

/**
 * Size of the data after it has been converted into pcm.
 */
	private int convertedBufferSize;

/**
 * Actual pcm data.
 */
	private float[][][] pcmInfo;

/**
 * Location within the data.
 */
	private int[] pcmIndex;

/**
 * Data packet.
 */
	private Packet joggPacket = new Packet();
/**
 * Data Page.
 */
	private Page joggPage = new Page();
/**
 * Stream state.
 */
	private StreamState joggStreamState = new StreamState();
/**
 * Packet streaming layer.
 */
	private SyncState joggSyncState = new SyncState();
/**
 * Internal data storage.
 */
	private DspState jorbisDspState = new DspState();
/**
 * Block of stored JOrbis data.
 */
	private Block jorbisBlock = new Block(jorbisDspState);
/**
 * Comment fields.
 */
	private Comment jorbisComment = new Comment();
/**
 * Info about the data.
 */
	private Info jorbisInfo = new Info();

/**
 * Processes status messages, warnings, and error messages.
 */
    private SoundSystemLogger logger;

/**
 * Constructor:  Grabs a handle to the logger.
 */
    public CodecJOrbis()
    {
        logger = SoundSystemConfig.getLogger();
    }

/**
 * This method is ignored by CodecJOrbis.
 */
    public void reverseByteOrder( boolean b )
    {
    }

/**
 * Prepares an input stream to read from.  If another stream is already opened,
 * it will be closed and a new input stream opened in its place.
 * @param url URL to an ogg file to stream from.
 * @return False if an error occurred or if end of stream was reached.
 */
    public boolean initialize( URL url )
    {
        initialized( SET, false );

        if( joggStreamState != null )
            joggStreamState.clear();
        if( jorbisBlock != null )
            jorbisBlock.clear();
        if( jorbisDspState != null )
            jorbisDspState.clear();
        if( jorbisInfo != null )
            jorbisInfo.clear();
        if( joggSyncState != null )
            joggSyncState.clear();

    	if( inputStream != null )
        {
            try
            {
                inputStream.close();
            }
            catch( IOException ioe )
            {}
        }

        this.url = url;
        this.bufferSize = SoundSystemConfig.getStreamingBufferSize() / 2;

        buffer = null;
        count = 0;
        index = 0;

        joggStreamState = new StreamState();
        jorbisBlock = new Block(jorbisDspState);
        jorbisDspState = new DspState();
        jorbisInfo = new Info();
        joggSyncState = new SyncState();

		try
		{
			urlConnection = url.openConnection();
		}
		catch( UnknownServiceException use )
		{
			errorMessage( "Unable to create a UrlConnection in method " +
                          "'initialize'." );
            printStackTrace( use );
            cleanup();
            return false;
		}
		catch( IOException ioe )
		{
			errorMessage( "Unable to create a UrlConnection in method " +
                          "'initialize'." );
            printStackTrace( ioe );
            cleanup();
            return false;
		}

		if( urlConnection != null )
		{
			try
			{
				inputStream = urlConnection.getInputStream();
			}
			catch( IOException ioe )
			{
				errorMessage( "Unable to acquire inputstream in method " +
                              "'initialize'." );
                printStackTrace( ioe );
                cleanup();
                return false;
			}
		}

        endOfStream( SET, false );

		joggSyncState.init();
		joggSyncState.buffer( bufferSize );
		buffer = joggSyncState.data;

        try
        {
            if( !readHeader() )
            {
                errorMessage( "Error reading the header" );
                return false;
            }
        }
        catch( IOException ioe )
        {
            errorMessage( "Error reading the header" );
            return false;
        }

		convertedBufferSize = bufferSize * 2;

		jorbisDspState.synthesis_init( jorbisInfo );
		jorbisBlock.init( jorbisDspState );

        int channels = jorbisInfo.channels;
		int rate = jorbisInfo.rate;

		audioFormat = new AudioFormat( (float) rate, 16, channels, true,
                                       false );

		pcmInfo = new float[1][][];
		pcmIndex = new int[ jorbisInfo.channels ];

        initialized( SET, true );

        return true;
    }

/**
 * Returns false if the stream is busy initializing.
 * @return True if steam is initialized.
 */
    public boolean initialized()
    {
        return initialized( GET, XXX );
    }

/**
 * Reads in one stream buffer worth of audio data.  See
 * {@link paulscode.sound.SoundSystemConfig SoundSystemConfig} for more
 * information about accessing and changing default settings.
 * @return The audio data wrapped into a SoundBuffer context.
 */
    public SoundBuffer read()
    {
        byte[] buff = readBytes();

        if( buff == null )
            return null;

        return new SoundBuffer( buff, audioFormat );
    }

/**
 * Reads in all the audio data from the stream (up to the default
 * "maximum file size".  See
 * {@link paulscode.sound.SoundSystemConfig SoundSystemConfig} for more
 * information about accessing and changing default settings.
 * @return the audio data wrapped into a SoundBuffer context.
 */
    public SoundBuffer readAll()
    {
        byte[] buff = readBytes();

        while( !endOfStream( GET, XXX ) )
        {
            buff = appendByteArrays( buff, readBytes() );
            if( buff != null && buff.length >=
                                            SoundSystemConfig.getMaxFileSize() )
                break;
        }

        return new SoundBuffer( buff, audioFormat );
    }

/**
 * Returns false if there is still more data available to be read in.
 * @return True if end of stream was reached.
 */
    public boolean endOfStream()
    {
        return endOfStream( GET, XXX );
    }

/**
 * Closes the input stream and remove references to all instantiated objects.
 */
	public void cleanup()
	{
		joggStreamState.clear();
		jorbisBlock.clear();
		jorbisDspState.clear();
		jorbisInfo.clear();
		joggSyncState.clear();

    	if( inputStream != null )
        {
            try
            {
                inputStream.close();
            }
            catch( IOException ioe )
            {}
        }

        joggStreamState = null;
        jorbisBlock = null;
        jorbisDspState = null;
        jorbisInfo = null;
        joggSyncState = null;
        inputStream = null;
	}

/**
 * Returns the audio format of the data being returned by the read() and
 * readAll() methods.
 * @return Information wrapped into an AudioFormat context.
 */
    public AudioFormat getAudioFormat()
    {
        return audioFormat;
    }

/**
 * Reads in the header information for the ogg file, which is contained in the
 * first three packets of data.
 * @return True if successful.
 */
	private boolean readHeader() throws IOException
	{
        // Update up JOrbis internal buffer:
        index = joggSyncState.buffer( bufferSize );
        // Read in a buffer of data:
        int bytes = inputStream.read( joggSyncState.data, index, bufferSize );
        if( bytes < 0 )
            bytes = 0;
        // Let JOrbis know how many bytes we got:
        joggSyncState.wrote( bytes );

        if( joggSyncState.pageout( joggPage ) != 1 )
        {
            // Finished reading the entire file:
            if( bytes < bufferSize )
                return true;

            errorMessage( "Ogg header not recognized in method 'readHeader'." );
            return false;
        }

        // Initialize JOrbis:
        joggStreamState.init( joggPage.serialno() );

        jorbisInfo.init();
        jorbisComment.init();
        if( joggStreamState.pagein( joggPage ) < 0 )
        {
            errorMessage( "Problem with first Ogg header page in method " +
                          "'readHeader'." );
            return false;
        }

        if( joggStreamState.packetout( joggPacket ) != 1 )
        {
            errorMessage( "Problem with first Ogg header packet in method " +
                          "'readHeader'." );
            return false;
        }

        if( jorbisInfo.synthesis_headerin( jorbisComment, joggPacket ) < 0 )
        {
            errorMessage( "File does not contain Vorbis header in method " +
                          "'readHeader'." );
            return false;
        }

        int i = 0;
        while( i < 2 )
        {
            while( i < 2 )
            {
                int result = joggSyncState.pageout( joggPage );
                if( result == 0 )
                    break;
                if( result == 1 )
                {
                    joggStreamState.pagein( joggPage );
                    while( i < 2 )
                    {
                        result = joggStreamState.packetout( joggPacket );
                        if( result == 0 )
                            break;

                        if( result == -1 )
                        {
                            errorMessage( "Secondary Ogg header corrupt in " +
                                          "method 'readHeader'." );
                            return false;
                        }

                        jorbisInfo.synthesis_headerin( jorbisComment,
                                                       joggPacket );
                        i++;
                    }
                }
            }
            index = joggSyncState.buffer( bufferSize );
            bytes = inputStream.read( joggSyncState.data, index, bufferSize );
            if( bytes < 0 )
                bytes = 0;
            if( bytes == 0 && i < 2 )
            {
                errorMessage( "End of file reached before finished reading" +
                              "Ogg header in method 'readHeader'" );
                return false;
            }

            joggSyncState.wrote( bytes );
        }
        
        index = joggSyncState.buffer( bufferSize );
        buffer = joggSyncState.data;

		return true;
	}

/**
 * Reads and decodes a chunk of data of length "convertedBufferSize".
 * @return Array containing the converted audio data.
 */
	private byte[] readBytes()
	{
        if( !initialized( GET, XXX ) )
            return null;

        if( endOfStream( GET, XXX ) )
            return null;

        byte[] returnBuffer = null;

        switch(joggSyncState.pageout(joggPage))
        {
            case -1:
            {}
            case 0:
            {
                // TODO:  Why is this needed here???
                endOfStream( SET, true );
                break;
            }
            case 1:
            {
                // Page complete
                joggStreamState.pagein( joggPage );
                if( joggPage.granulepos() == 0 )
                {
                    endOfStream( SET, true );
                    break;
                }
                processPackets: while( true )
                {
                    switch( joggStreamState.packetout( joggPacket ) )
                    {
                        case -1:
                        {}
                        case 0:
                        {
                            // Need to read more data.
                            break processPackets;
                        }
                        case 1:
                        {
                            // Packet complete
                            returnBuffer = appendByteArrays( returnBuffer,
                                                        decodeCurrentPacket() );
                        }
                    }
                }
                if( joggPage.eos() != 0 )
                    endOfStream( SET, true );
            }
        }
        if( !endOfStream( GET, XXX ) )
        {
            index = joggSyncState.buffer( bufferSize );
            if( index == -1 )
                endOfStream( SET, true );
            else
            {
                buffer = joggSyncState.data;
                try
                {
                    // read in a block of data
                    count = inputStream.read( buffer, index, bufferSize );
                }
                catch( Exception e )
                {
                    printStackTrace( e );
                    return returnBuffer;
                }
                joggSyncState.wrote( count );
                if( count == 0 )
                    endOfStream( SET, true );
            }
        }
        return returnBuffer;
    }

/**
 * Converts the data that has been read in so far into pcm format.
 * @return Array containing the converted audio data.
 */
	private byte[] decodeCurrentPacket()
	{
		byte[] convertedBuffer = new byte[ convertedBufferSize ];

		int samples;

		if( jorbisBlock.synthesis( joggPacket ) == 0 )
			jorbisDspState.synthesis_blockin( jorbisBlock );

		int range;
        int maxRange = convertedBufferSize / ( jorbisInfo.channels * 2 );
        int convertedDataLength = 0;

		while( ( convertedDataLength < convertedBufferSize ) && ( ( samples =
                  jorbisDspState.synthesis_pcmout( pcmInfo, pcmIndex ) ) > 0 ) )
		{
			if( samples < maxRange )
				range = samples;
			else
				range = maxRange;
			for( int i = 0; i < jorbisInfo.channels; i++ )
			{
				int sampleIndex = i * 2;
				for( int j = 0; j < range; j++ )
				{
					int value = (int) ( pcmInfo[0][i][pcmIndex[i] + j] *
                                                                        32767 );
					if( value > 32767 )
					{
						value = 32767;
					}
					if( value < -32768 )
					{
						value = -32768;
					}
					if( value < 0 )
                        value = value | 32768;
					convertedBuffer[ convertedDataLength + sampleIndex ] =
                                                               (byte) ( value );
					convertedBuffer[ convertedDataLength + sampleIndex + 1 ] =
                                                         (byte) ( value >>> 8 );

					sampleIndex += 2 * ( jorbisInfo.channels );
				}
			}
            convertedDataLength += range * jorbisInfo.channels * 2;
			jorbisDspState.synthesis_read( range );
		}
        convertedBuffer = trimArray( convertedBuffer, convertedDataLength );

        return convertedBuffer;
	}

/**
 * Internal method for synchronizing access to the boolean 'initialized'.
 * @param action GET or SET.
 * @param value New value if action == SET, or XXX if action == GET.
 * @return True if steam is initialized.
 */
    private synchronized boolean initialized( boolean action, boolean value )
    {
        if( action == SET )
            initialized = value;
        return initialized;
    }

/**
 * Internal method for synchronizing access to the boolean 'endOfStream'.
 * @param action GET or SET.
 * @param value New value if action == SET, or XXX if action == GET.
 * @return True if end of stream was reached.
 */
    private synchronized boolean endOfStream( boolean action, boolean value )
    {
        if( action == SET )
            endOfStream = value;
        return endOfStream;
    }

/**
 * Trims down the size of the array if it is larger than the specified
 * maximum length.
 * @param array Array containing audio data.
 * @param maxLength Maximum size this array may be.
 * @return New array.
 */
    private static byte[] trimArray( byte[] array, int maxLength )
    {
        byte[] trimmedArray = null;
        if( array != null && array.length > maxLength )
        {
            trimmedArray = new byte[maxLength];
            System.arraycopy( array, 0, trimmedArray, 0, maxLength );
        }
        return trimmedArray;
    }

/**
 * Creates a new array with the second array appended to the end of the first
 * array.
 * @param arrayOne The first array.
 * @param arrayTwo The second array.
 * @return Byte array containing information from both arrays.
 */
    private static byte[] appendByteArrays( byte[] arrayOne, byte[] arrayTwo )
    {
        byte[] newArray;
        if( arrayOne == null && arrayTwo == null )
        {
            // no data, just return
            return null;
        }
        else if( arrayOne == null )
        {
            // create the new array, same length as arrayTwo:
            newArray = new byte[ arrayTwo.length ];
            // fill the new array with the contents of arrayTwo:
            System.arraycopy( arrayTwo, 0, newArray, 0, arrayTwo.length );
            arrayTwo = null;
        }
        else if( arrayTwo == null )
        {
            // create the new array, same length as arrayOne:
            newArray = new byte[ arrayOne.length ];
            // fill the new array with the contents of arrayOne:
            System.arraycopy( arrayOne, 0, newArray, 0, arrayOne.length );
            arrayOne = null;
        }
        else
        {
            // create the new array large enough to hold both arrays:
            newArray = new byte[ arrayOne.length + arrayTwo.length ];
            System.arraycopy( arrayOne, 0, newArray, 0, arrayOne.length );
            // fill the new array with the contents of both arrays:
            System.arraycopy( arrayTwo, 0, newArray, arrayOne.length,
                              arrayTwo.length );
            arrayOne = null;
            arrayTwo = null;
        }

        return newArray;
    }

/**
 * Prints an error message.
 * @param message Message to print.
 */
    private void errorMessage( String message )
    {
        logger.errorMessage( "CodecJOrbis", message, 0 );
    }

/**
 * Prints an exception's error message followed by the stack trace.
 * @param e Exception containing the information to print.
 */
    private void printStackTrace( Exception e )
    {
        logger.printStackTrace( e, 1 );
    }
}
